<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="js.js"></script>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css"
          crossorigin="anonymous">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Pharmacy | Home</title>
</head>
<body>

<?php
session_start();
?>
<div class="page-wrapper chiller-theme toggled">
    <a id="show-sidebar" class="btn btn-sm btn-dark" href="#">
        <i class="fas fa-bars"></i>
    </a>
    <nav id="sidebar" class="sidebar-wrapper">
        <div class="sidebar-content">
            <div class="sidebar-brand">
                <a href="#">dashboard</a>
                <div id="close-sidebar">
                    <i class="fas fa-times"></i>
                </div>
            </div>
            <div class="sidebar-header">
                <div class="user-info">
                  <span class="user-name"><i class="fas fa-user"></i> &nbsp;&nbsp; &nbsp;&nbsp; <?php echo $_SESSION["email"]; ?> John
                    <strong>Smith</strong>
                  </span>
                </div>
            </div>
            <!-- sidebar-header  -->
            <div class="sidebar-search">
                <div>
                    <div class="input-group">
                        <input type="text" class="form-control search-menu" placeholder="Search...">
                        <div class="input-group-append">
                      <span class="input-group-text">
                        <i class="fa fa-search" aria-hidden="true"></i>
                      </span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- sidebar-search  -->
            <div class="sidebar-menu">
                <ul>
                    <li class="header-menu">
                        <span>General</span>
                    </li>
                    <li class="sidebar-dropdown">
                        <a href="#">
                            <i class="fa fa-tachometer-alt"></i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li class="sidebar-dropdown">
                        <a href="#">
                            <i class="fas fa-box-open"></i>
                            <span>Stock Management</span>
                        </a>
                    </li>
                    <li class="sidebar-dropdown">
                        <a href="#">
                            <i class="far fa-gem"></i>
                            <span>Components</span>
                        </a>
                    </li>
                    <li class="sidebar-dropdown">
                        <a href="#">
                            <i class="fa fa-chart-line"></i>
                            <span>Charts</span>
                        </a>
                    </li>
                    <li class="sidebar-dropdown">
                        <a href="#">
                            <i class="fa fa-globe"></i>
                            <span>Maps</span>
                        </a>
                    </li>
                    <li class="header-menu">
                        <span>Extra</span>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa fa-book"></i>
                            <span>Documentation</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa fa-calendar"></i>
                            <span>Calendar</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa fa-folder"></i>
                            <span>Examples</span>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- sidebar-menu  -->
        </div>
        <!-- sidebar-content  -->
        <div class="sidebar-footer">
            <a href="#">
                <i class="fa fa-power-off"></i>
            </a>
        </div>
    </nav>
    <!-- sidebar-wrapper  -->
    <!-- page-content" -->
</div>
<!-- patients -->
    <div class="container padding40 paddinglr0">
        <div class="row personrow mx-auto">
            <div class="col align-self-center">
                <img src="https://st3.depositphotos.com/13159112/17145/v/450/depositphotos_171453724-stock-illustration-default-avatar-profile-icon-grey.jpg">
            </div>
            <div class="col align-self-center text-center">
                <span class="label-blue"> Patient </span> <br>
                <div class="person-name patientfsize"> John Smith </div>
            </div>
            <div class="col align-self-center text-center">
                <div class="persid">
                    <span class="label-blue"> Patient ID </span> <br>
                    <span class="person-id patientfsize"> 193636 </span>
                </div>
            </div>
            <div class="col align-self-center text-center">
                <div class="prescription-status justify-content-center">
                    <span class="label-blue"> Status </span> <br>
                    <span class="person-id percol patientfsize"> Prescription Ready </span>
                </div>
            </div>
        </div>
    </div>

    <div class="row personrow mx-auto">
        <div class="col align-self-center">
            <img src="https://st3.depositphotos.com/13159112/17145/v/450/depositphotos_171453724-stock-illustration-default-avatar-profile-icon-grey.jpg">
        </div>
        <div class="col align-self-center text-center">
            <span class="label-blue"> Patient </span> <br>
            <div class="person-name patientfsize"> John Smith </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="persid">
                <span class="label-blue"> Patient ID </span> <br>
                <span class="person-id patientfsize"> 193636 </span>
            </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="prescription-status justify-content-center">
                <span class="label-blue"> Status </span> <br>
                <span class="person-id percol patientfsize"> Prescription Ready </span>
            </div>
        </div>
    </div>

    <div class="row personrow mx-auto">
        <div class="col align-self-center">
            <img src="https://st3.depositphotos.com/13159112/17145/v/450/depositphotos_171453724-stock-illustration-default-avatar-profile-icon-grey.jpg">
        </div>
        <div class="col align-self-center text-center">
            <span class="label-blue"> Patient </span> <br>
            <div class="person-name patientfsize"> John Smith </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="persid">
                <span class="label-blue"> Patient ID </span> <br>
                <span class="person-id patientfsize"> 193636 </span>
            </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="prescription-status justify-content-center">
                <span class="label-blue"> Status </span> <br>
                <span class="person-id percol patientfsize"> Prescription Ready </span>
            </div>
        </div>
    </div>

    <div class="row personrow mx-auto">
        <div class="col align-self-center">
            <img src="https://st3.depositphotos.com/13159112/17145/v/450/depositphotos_171453724-stock-illustration-default-avatar-profile-icon-grey.jpg">
        </div>
        <div class="col align-self-center text-center">
            <span class="label-blue"> Patient </span> <br>
            <div class="person-name patientfsize"> John Smith </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="persid">
                <span class="label-blue"> Patient ID </span> <br>
                <span class="person-id patientfsize"> 193636 </span>
            </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="prescription-status justify-content-center">
                <span class="label-blue"> Status </span> <br>
                <span class="person-id percol patientfsize"> Prescription Ready </span>
            </div>
        </div>
    </div>

    <div class="row personrow mx-auto">
        <div class="col align-self-center">
            <img src="https://st3.depositphotos.com/13159112/17145/v/450/depositphotos_171453724-stock-illustration-default-avatar-profile-icon-grey.jpg">
        </div>
        <div class="col align-self-center text-center">
            <span class="label-blue"> Patient </span> <br>
            <div class="person-name patientfsize"> John Smith </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="persid">
                <span class="label-blue"> Patient ID </span> <br>
                <span class="person-id patientfsize"> 193636 </span>
            </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="prescription-status justify-content-center">
                <span class="label-blue"> Status </span> <br>
                <span class="person-id percol patientfsize"> Prescription Ready </span>
            </div>
        </div>
    </div>

    <div class="row personrow mx-auto">
        <div class="col align-self-center">
            <img src="https://st3.depositphotos.com/13159112/17145/v/450/depositphotos_171453724-stock-illustration-default-avatar-profile-icon-grey.jpg">
        </div>
        <div class="col align-self-center text-center">
            <span class="label-blue"> Patient </span> <br>
            <div class="person-name patientfsize"> John Smith </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="persid">
                <span class="label-blue"> Patient ID </span> <br>
                <span class="person-id patientfsize"> 193636 </span>
            </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="prescription-status justify-content-center">
                <span class="label-blue"> Status </span> <br>
                <span class="person-id percol patientfsize"> Prescription Ready </span>
            </div>
        </div>
    </div>

    <div class="row personrow mx-auto">
        <div class="col align-self-center">
            <img src="https://st3.depositphotos.com/13159112/17145/v/450/depositphotos_171453724-stock-illustration-default-avatar-profile-icon-grey.jpg">
        </div>
        <div class="col align-self-center text-center">
            <span class="label-blue"> Patient </span> <br>
            <div class="person-name patientfsize"> John Smith </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="persid">
                <span class="label-blue"> Patient ID </span> <br>
                <span class="person-id patientfsize"> 193636 </span>
            </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="prescription-status justify-content-center">
                <span class="label-blue"> Status </span> <br>
                <span class="person-id percol patientfsize"> Prescription Ready </span>
            </div>
        </div>
    </div>

    <div class="row personrow mx-auto">
        <div class="col align-self-center">
            <img src="https://st3.depositphotos.com/13159112/17145/v/450/depositphotos_171453724-stock-illustration-default-avatar-profile-icon-grey.jpg">
        </div>
        <div class="col align-self-center text-center">
            <span class="label-blue"> Patient </span> <br>
            <div class="person-name patientfsize"> John Smith </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="persid">
                <span class="label-blue"> Patient ID </span> <br>
                <span class="person-id patientfsize"> 193636 </span>
            </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="prescription-status justify-content-center">
                <span class="label-blue"> Status </span> <br>
                <span class="person-id percol patientfsize"> Prescription Ready </span>
            </div>
        </div>
    </div>

    <div class="row personrow mx-auto">
        <div class="col align-self-center">
            <img src="https://st3.depositphotos.com/13159112/17145/v/450/depositphotos_171453724-stock-illustration-default-avatar-profile-icon-grey.jpg">
        </div>
        <div class="col align-self-center text-center">
            <span class="label-blue"> Patient </span> <br>
            <div class="person-name patientfsize"> John Smith </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="persid">
                <span class="label-blue"> Patient ID </span> <br>
                <span class="person-id patientfsize"> 193636 </span>
            </div>
        </div>
        <div class="col align-self-center text-center">
            <div class="prescription-status justify-content-center">
                <span class="label-blue"> Status </span> <br>
                <span class="person-id percol patientfsize"> Prescription Ready </span>
            </div>
        </div>
    </div>
<!-- patients end -->
</body>
</html>