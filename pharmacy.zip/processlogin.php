<html>
<body>

Your email address is: <?php echo $_POST["email"]; ?>

<?php
    // Start a new session
    session_start();

    // Retrieve username and password submitted by user
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Establishing connection to the database
    $conn = mysqli_connect("localhost", "root", "", "pharmacydb");
    mysqli_select_db($conn, "pharmacydb");

    // Protection against malicious SQL injection
    $email = stripcslashes($email);
    $password = stripcslashes($password);
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);

    // SQL Query to compare submitted data to the database
    $result = mysqli_query($conn,"select * from staff where email = '$email' and password= '$password'") or die("Database query failed".mysqli_error());
    $row = mysqli_fetch_array($result);
    if ($row['email'] == $email && $row['password'] == $password){
        echo "Login successful";
    } else {
        echo "Login failed.";
    }

    $_SESSION["email"] = $email;
    $_SESSION["password"] = $password;
    mysqli_close($conn);
    header("Location: /pharmacy/home.php");
    ?>
</body>
</html>